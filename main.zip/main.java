public interface StoreOperations {
    void addProduct(Product product);
    void buyProduct(int productId, int quantity);
    void viewCart();
    void checkout();
}
public abstract class Product {
    protected int productID;
    protected String name;
    protected double price;
    protected int stock;

    // Constructor
    public Product(int productID, String name, double price, int stock) {
        this.productID = productID;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    // Getters
    public int getProductID() {
        return productID;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    // Setters
    public void setStock(int stock) {
        this.stock = stock;
    }

    // Abstract method to display product details
    public abstract void displayProduct();
}
import java.util.*;

public class OnlineStore implements StoreOperations {
    private List<Product> inventory = new ArrayList<>();
    private Map<Integer, Integer> cart = new HashMap<>();
    
    @Override
    public void addProduct(Product product) {
        inventory.add(product);
        System.out.println("Product " + product.getName() + " added to the store.");
    }

    @Override
    public void buyProduct(int productId, int quantity) {
        for (Product product : inventory) {
            if (product.getProductID() == productId) {
                if (product.getStock() >= quantity) {
                    product.setStock(product.getStock() - quantity);
                    cart.put(productId, cart.getOrDefault(productId, 0) + quantity);
                    System.out.println("Added " + quantity + " of " + product.getName() + " to the cart.");
                } else {
                    System.out.println("Insufficient stock for " + product.getName());
                }
                return;
            }
        }
        System.out.println("Product not found.");
    }

    @Override
    public void viewCart() {
        System.out.println("\nCart Contents:");
        if (cart.isEmpty()) {
            System.out.println("Cart is empty.");
        } else {
            for (Map.Entry<Integer, Integer> entry : cart.entrySet()) {
                int productId = entry.getKey();
                int quantity = entry.getValue();
                for (Product product : inventory) {
                    if (product.getProductID() == productId) {
                        System.out.println("Product: " + product.getName() + ", Quantity: " + quantity + ", Price: " + product.getPrice());
                    }
                }
            }
        }
    }

    @Override
    public void checkout() {
        double total = 0;
        System.out.println("\nCheckout Details:");
        for (Map.Entry<Integer, Integer> entry : cart.entrySet()) {
            int productId = entry.getKey();
            int quantity = entry.getValue();
            for (Product product : inventory) {
                if (product.getProductID() == productId) {
                    total += product.getPrice() * quantity;
                    System.out.println("Product: " + product.getName() + ", Quantity: " + quantity + ", Price: " + product.getPrice());
                }
            }
        }
        System.out.println("Total Amount: " + total);
        cart.clear();  // Empty cart after checkout
        System.out.println("Checkout complete. Thank you for shopping!");
    }

    // Method to display all products in the store
    public void displayProducts() {
        System.out.println("\nProducts in Store:");
        for (Product product : inventory) {
            product.displayProduct();
        }
    }
}
public class ElectronicProduct extends Product {

    public ElectronicProduct(int productID, String name, double price, int stock) {
        super(productID, name, price, stock);
    }

    @Override
    public void displayProduct() {
        System.out.println("ID: " + productID + ", Name: " + name + ", Price: $" + price + ", Stock: " + stock);
    }
}
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        OnlineStore store = new OnlineStore();
        
        // Adding some products to the store
        store.addProduct(new ElectronicProduct(1, "Laptop", 1200.00, 5));
        store.addProduct(new ElectronicProduct(2, "Smartphone", 800.00, 10));
        store.addProduct(new ElectronicProduct(3, "Headphones", 150.00, 20));

        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nWelcome to the Online Store!");
            System.out.println("1. View Products");
            System.out.println("2. Add Product to Cart");
            System.out.println("3. View Cart");
            System.out.println("4. Checkout");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    store.displayProducts();
                    break;
                case 2:
                    System.out.print("Enter product ID to add to cart: ");
                    int productId = scanner.nextInt();
                    System.out.print("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    store.buyProduct(productId, quantity);
                    break;
                case 3:
                    store.viewCart();
                    break;
